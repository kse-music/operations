<script setup lang="ts">
import { tr } from '../i18n/messages';

import { onMounted, ref } from 'vue';
import { X } from '@lucide/vue';
const props = defineProps<{ title: string; busy?: boolean; wide?: boolean }>();
const emit = defineEmits<{ close: [] }>();
const dialog = ref<HTMLDialogElement | null>(null);
onMounted(() => dialog.value?.showModal());
function close(): void {
  if (!props.busy) emit('close');
}
</script>
<template>
  <Teleport to="body">
    <dialog ref="dialog" :class="['modal', { wide }]" :aria-label="title" @cancel.prevent="close">
      <header class="modal-heading">
        <h2>{{ title }}</h2>
        <button
          class="icon-button"
          type="button"
          :aria-label="tr('关闭对话框')"
          :title="tr('关闭对话框')"
          :disabled="busy"
          @click="close"
        >
          <X :size="16" aria-hidden="true" />
        </button>
      </header>
      <slot />
    </dialog>
  </Teleport>
</template>
